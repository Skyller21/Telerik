﻿namespace BatkaGame
{
    interface IDraw
    {
        void Draw();
    }
}
