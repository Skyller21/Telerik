﻿namespace LoquatMegaStore.Enumerators
{
    public enum DisplayResolution
    {
        p480, p720, p1024, p1920 , UHD
    }
}
