﻿namespace LoquatMegaStore.Enumerators
{
    public enum BatteryType
    {
        LiPoly, LiIon, SlimBattery, StandardBattery, ExtendedBattery, NiCD, NiMH
    }
}
