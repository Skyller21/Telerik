﻿namespace LoquatMegaStore.ShoppingSystem.Enumerators
{
    using System;

    public enum PaymentType
    {
        Cash,WireTransaction,CreditCard
    }
}
