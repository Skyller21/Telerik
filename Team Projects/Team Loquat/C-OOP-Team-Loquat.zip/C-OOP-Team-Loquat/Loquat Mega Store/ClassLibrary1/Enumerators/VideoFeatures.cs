﻿namespace LoquatMegaStore.Enumerators
{
    public enum VideoFeatures
    {
        VGA, SVGA, XGA, SuperXGA, MAC, HDTV, DVI, RGBHV, HDB15, DVD, SVideo, USB, PS2 
    }
}
