﻿namespace LoquatMegaStore.Enumerators
{
    public enum ProjectorType
    {
        StandardLCD, PolysiliconLCD, DLP
    }
}
