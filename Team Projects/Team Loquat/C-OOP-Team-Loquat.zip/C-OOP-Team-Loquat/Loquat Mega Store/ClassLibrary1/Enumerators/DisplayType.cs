﻿namespace LoquatMegaStore.Enumerators
{
    public enum DisplayType
    {
        LCD, TFT, LED, OLED, Plasma, SUHD
    }
}
