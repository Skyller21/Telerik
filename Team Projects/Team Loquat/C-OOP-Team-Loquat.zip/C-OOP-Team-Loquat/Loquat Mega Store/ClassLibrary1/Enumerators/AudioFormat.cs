﻿namespace LoquatMegaStore.Enumerators
{
    public enum AudioFormat
    {
        МP3, AACLC, LPCM, WMA, AVC, WMV, MPEG4
    }
}
