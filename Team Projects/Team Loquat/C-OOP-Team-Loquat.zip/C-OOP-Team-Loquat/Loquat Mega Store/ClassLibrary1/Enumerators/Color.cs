﻿namespace LoquatMegaStore.Enumerators
{
    public enum Color
    {
        White, Black, Blue, Yellow, Green, Red, Cyan, Magenta, Orange, Gray
    }
}
