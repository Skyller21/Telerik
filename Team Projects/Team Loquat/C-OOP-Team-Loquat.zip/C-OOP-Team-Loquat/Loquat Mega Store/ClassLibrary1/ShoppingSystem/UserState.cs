﻿namespace LoquatMegaStore.ShoppingSystem
{
    public enum UserState
    {
        New,
        Active,
        Blocked,
        Banned
    }
}
