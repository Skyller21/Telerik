﻿namespace LoquatMegaStore.Interfaces
{
    public interface ICartAddable
    {
        void AddToCart();
    }
}
