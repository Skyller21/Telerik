﻿namespace LoquatMegaStore.Interfaces
{
    public interface IOrder
    {
        void MakeOrder(string contactName,string address);
    }
}
