﻿namespace LoquatMegaStore.Interfaces
{
    public interface IPayable
    {
        void MakePayment();
    }
}
