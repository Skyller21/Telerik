﻿namespace LoquatMegaStore.Interfaces
{
    public interface ICommunicational
    {
    }
}
