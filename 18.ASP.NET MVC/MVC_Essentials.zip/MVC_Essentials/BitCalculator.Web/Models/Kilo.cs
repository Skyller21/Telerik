﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitCalculator.Web.Models
{
    public enum Kilo
    {
        Bandwidth = 1000,
        Storage = 1024
    }
}