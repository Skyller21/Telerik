BitCalculator contains all the tasks.
The project is not separated. Didn't have time for this :D