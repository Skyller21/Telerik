var textQuote = '"One does not simply quote a text in JS" - Doncho said';
console.log(textQuote);