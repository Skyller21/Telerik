var none = null;
var undef = undefined;
var nan = NaN;

console.log('var none: ' + typeof none);
console.log('var undef: ' + typeof undef);
console.log('var nan: ' + typeof nan);